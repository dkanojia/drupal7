Users : 

First User : drupalUser
Pwd : drupal123

Second User : siteAdmin
Pwd : 123456